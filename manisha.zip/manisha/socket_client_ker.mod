/home/team2/manisha/socket_client_ker.o
