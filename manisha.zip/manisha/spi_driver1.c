
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/io.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>

#define SPI_BASE_ADDR  0xFE204000   /* Example: RPi SPI0 */
#define SPI_SIZE       0x100

#define CS    0x00
#define FIFO  0x04
#define CLK   0x08
#define DLEN  0x0C

#define DEVICE_NAME "spi_data"

static int major;
static void __iomem *base;
static DEFINE_MUTEX(spi_lock);

/* ---------- SPI INIT ---------- */
static void spi_init_hw(void)
{
	u32 cs;

	/* Disable SPI */
	writel(0x0, base + CS);

	/* Clear FIFOs */
	writel((1 << 4) | (1 << 5), base + CS);

	/* CPOL = 1, CPHA = 1, CS = 0 */
	cs = readl(base + CS);
	cs |= (1 << 3);          /* CPOL */
	cs |= (1 << 2);          /* CPHA */
	cs &= ~(3 << 4);         /* CS = 0 */
	writel(cs, base + CS);

	/* Clock divider */
	writel(100, base + CLK);

	pr_info("SPI initialized\n");
}

/* ---------- WRITE ---------- */
static ssize_t spi_write(struct file *file,
                         const char __user *buf,
