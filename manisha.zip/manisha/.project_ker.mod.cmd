savedcmd_/home/team2/manisha/project_ker.mod := printf '%s\n'   project_ker.o | awk '!x[$$0]++ { print("/home/team2/manisha/"$$0) }' > /home/team2/manisha/project_ker.mod
