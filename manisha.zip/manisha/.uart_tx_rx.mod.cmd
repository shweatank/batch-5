savedcmd_/home/team2/manisha/uart_tx_rx.mod := printf '%s\n'   uart_tx_rx.o | awk '!x[$$0]++ { print("/home/team2/manisha/"$$0) }' > /home/team2/manisha/uart_tx_rx.mod
