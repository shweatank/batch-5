#include<stdio.h>
volatile unsigned long *IO0DIR;
volatile unsigned long *IO0SET;
volatile unsigned long *IO0CLR;

void delay(void)
{
    unsigned long i;
    for(i = 0; i < 500000; i++);
}

int main(void)
{
    IO0DIR = (volatile unsigned long *)0xE0028008;
    IO0SET = (volatile unsigned long *)0xE0028004;
    IO0CLR = (volatile unsigned long *)0xE002800C;
    *IO0DIR |= 1;

    while(1)
    {
        *IO0CLR =1;
        delay();
        *IO0SET =1;
        delay();
    }
}

 
