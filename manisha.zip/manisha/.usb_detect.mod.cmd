savedcmd_/home/team2/manisha/usb_detect.mod := printf '%s\n'   usb_detect.o | awk '!x[$$0]++ { print("/home/team2/manisha/"$$0) }' > /home/team2/manisha/usb_detect.mod
