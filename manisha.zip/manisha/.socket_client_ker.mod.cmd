savedcmd_/home/team2/manisha/socket_client_ker.mod := printf '%s\n'   socket_client_ker.o | awk '!x[$$0]++ { print("/home/team2/manisha/"$$0) }' > /home/team2/manisha/socket_client_ker.mod
