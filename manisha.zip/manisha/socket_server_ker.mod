/home/team2/manisha/socket_server_ker.o
