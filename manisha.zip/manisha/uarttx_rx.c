#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/gpio.h>
#include <linux/delay.h>
#include <linux/file.h>
#include <linux/tty.h>

#define DEVICE_NAME "uart_led"
#define LED_GPIO 17

static int major;
static struct file *uart_filp;

/* ---------- UART helpers ---------- */
static int uart_open_port(void)
{
    uart_filp = filp_open("/dev/ttyAMA0", O_RDWR | O_NOCTTY, 0);
    if (IS_ERR(uart_filp)) {
        pr_err("UART open failed\n");
        return PTR_ERR(uart_filp);
    }
    return 0;
}

static void uart_close_port(void)
{
    if (uart_filp)
        filp_close(uart_filp, NULL);
}

static ssize_t uart_send(const char *buf, size_t len)
{
    return kernel_write(uart_filp, buf, len, &uart_filp->f_pos);
}

static ssize_t uart_receive(char *buf, size_t len)
{
    return kernel_read(uart_filp, buf, len, &uart_filp->f_pos);
}

/* ---------- LED blink ---------- */
static void blink_led(void)
{
    gpio_set_value(LED_GPIO, 1);
    msleep(200);
    gpio_set_value(LED_GPIO, 0);
}

/* ---------- File operations ---------- */
static ssize_t dev_write(struct file *f, const char __user *ubuf,
                         size_t len, loff_t *off)
{
    char kbuf[64];

    if (len > sizeof(kbuf))
        len = sizeof(kbuf);

    if (copy_from_user(kbuf, ubuf, len))
        return -EFAULT;

    blink_led();              // blink LED on write
    uart_send(kbuf, len);     // transmit UART

    return len;
}

static ssize_t dev_read(struct file *f, char __user *ubuf,
                        size_t len, loff_t *off)
{
    char kbuf[64];
    ssize_t ret;

    ret = uart_receive(kbuf, sizeof(kbuf));
    if (ret <= 0)
        return 0;

    if (copy_to_user(ubuf, kbuf, ret))
        return -EFAULT;

    blink_led();              // blink LED on read
    return ret;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .read = dev_read,
    .write = dev_write,
};

/* ---------- Init / Exit ---------- */
static int __init uart_led_init(void)
{
    major = register_chrdev(0, DEVICE_NAME, &fops);
    if (major < 0)
        return major;

    gpio_request(LED_GPIO, "led");
    gpio_direction_output(LED_GPIO, 0);

    uart_open_port();

    pr_info("uart_led driver loaded\n");
    return 0;
}

static void __exit uart_led_exit(void)
{
    uart_close_port();
    gpio_set_value(LED_GPIO, 0);
    gpio_free(LED_GPIO);
    unregister_chrdev(major, DEVICE_NAME);
    pr_info("uart_led driver unloaded\n");
}

module_init(uart_led_init);
module_exit(uart_led_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Example");
MODULE_DESCRIPTION("UART TX/RX + LED Blink Driver");

