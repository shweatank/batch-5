/dts-v1/;
/plugin/;

#include <dt-bindings/gpio/gpio.h>

 / {
    fragment@0 {
        targ
