/home/team2/manisha/usb_detect.o
